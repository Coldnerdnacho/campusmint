"""
CampusMint FastAPI Backend
University fintech + NFT ticketing system on Algorand Testnet
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging

from app.routers import vault, event, ticket, treasury, health
from app.services.database import init_db
from app.services.algo_client import AlgorandClient

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI
app = FastAPI(
    title="CampusMint API",
    description="University fintech + NFT ticketing on Algorand",
    version="1.0.0"
)

# CORS configuration for mobile/web clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Algorand client
algo_client = None


@app.on_event("startup")
async def startup_event():
    """Initialize database and Algorand client on startup"""
    global algo_client
    logger.info("🚀 CampusMint API starting...")
    
    try:
        # Initialize database
        init_db()
        logger.info("✅ Database initialized")
        
        # Initialize Algorand client
        algo_client = AlgorandClient()
        logger.info("✅ Algorand Testnet connected")
        
        app.state.algo_client = algo_client
        
    except Exception as e:
        logger.error(f"❌ Startup failed: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("👋 CampusMint API shutting down...")


# Include routers
app.include_router(health.router, prefix="/health", tags=["Health"])
app.include_router(vault.router, prefix="/vault", tags=["Student Vault"])
app.include_router(event.router, prefix="/event", tags=["Events"])
app.include_router(ticket.router, prefix="/ticket", tags=["NFT Tickets"])
app.include_router(treasury.router, prefix="/treasury", tags=["Treasury"])


# Global error handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": str(exc), "error": exc.__class__.__name__}
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

# CampusMint API - Sample Requests & Responses

## Health Check

### Request
```bash
curl http://localhost:8000/health/
```

### Response (200)
```json
{
  "status": "healthy",
  "service": "CampusMint API",
  "timestamp": "2024-02-15T10:30:45.123456"
}
```

---

## Vault - Deposit

### Request
```bash
curl -X POST http://localhost:8000/vault/deposit \
  -H "Content-Type: application/json" \
  -d '{
    "signed_txn": "iqNhbXS...[base64 encoded transaction]...==",
    "amount": 5000.00,
    "lock_days": 30
  }'
```

### Response (200)
```json
{
  "success": true,
  "txid": "AQZGAAA...",
  "explorer_url": "https://testnet.algoexplorer.io/tx/AQZGAAA...",
  "message": "Deposit successful",
  "confirmed_round": 60432835
}
```

### Error Response (400)
```json
{
  "detail": "Invalid transaction format"
}
```

---

## Vault - Get Balance

### Request
```bash
curl http://localhost:8000/vault/balance/C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4
```

### Response (200)
```json
{
  "address": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
  "balance_cinr": 50000.00,
  "balance_usd": 600.00,
  "account_age_days": 15,
  "can_withdraw": false
}
```

---

## Vault - Withdraw

### Request
```bash
curl -X POST http://localhost:8000/vault/withdraw \
  -H "Content-Type: application/json" \
  -d '{
    "signed_txn": "iqNhbXS...[base64 encoded transaction]...==",
    "reason": "emergency",
    "emergency_password": "secure_password_123"
  }'
```

### Response (200)
```json
{
  "success": true,
  "txid": "AQZGAAA...",
  "explorer_url": "https://testnet.algoexplorer.io/tx/AQZGAAA...",
  "message": "Emergency withdrawal processed",
  "confirmed_round": 60432850
}
```

---

## Events - Create

### Request
```bash
curl -X POST http://localhost:8000/event/create \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Freshers Party 2024",
    "description": "Welcome to campus! 🎉",
    "location": "Main Auditorium",
    "date": "2024-03-15",
    "ticket_price": 500.00,
    "max_tickets": 1000,
    "organizer_address": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4"
  }'
```

### Response (200)
```json
{
  "success": true,
  "event_id": 755379222,
  "name": "Freshers Party 2024",
  "created_at": "2024-02-15T10:30:45.123456"
}
```

---

## Events - List

### Request
```bash
curl http://localhost:8000/event/list?limit=10
```

### Response (200)
```json
{
  "events": [
    {
      "id": 755379222,
      "name": "Freshers Party 2024",
      "date": "2024-03-15",
      "location": "Main Auditorium",
      "tickets_sold": 250,
      "available": 750,
      "organizer": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4"
    }
  ],
  "count": 1
}
```

---

## Events - Get Details

### Request
```bash
curl http://localhost:8000/event/755379222
```

### Response (200)
```json
{
  "id": 755379222,
  "name": "Freshers Party 2024",
  "description": "Welcome to campus! 🎉",
  "location": "Main Auditorium",
  "date": "2024-03-15",
  "ticket_price": 500.00,
  "max_tickets": 1000,
  "tickets_sold": 250,
  "available_tickets": 750,
  "organizer": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
  "nft_asset_id": 123456,
  "created_at": "2024-02-15T10:30:45.123456"
}
```

---

## Events - Purchase Ticket

### Request
```bash
curl -X POST http://localhost:8000/event/755379222/pay \
  -H "Content-Type: application/json" \
  -d '{
    "signed_txn": "iqNhbXS...[base64 encoded transaction]...=="
  }'
```

### Response (200)
```json
{
  "success": true,
  "txid": "AQZGAAA...",
  "explorer_url": "https://testnet.algoexplorer.io/tx/AQZGAAA...",
  "message": "Ticket purchased for Freshers Party 2024",
  "confirmed_round": 60432860
}
```

---

## Tickets - Register

### Request
```bash
curl -X POST "http://localhost:8000/ticket/755379222/register?ticket_asset_id=123456&buyer_address=C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4&price_paid=500.00"
```

### Response (200)
```json
{
  "success": true,
  "ticket_asset_id": 123456,
  "qr_payload": "{\"event_id\": 755379222, \"wallet\": \"C57VRWF...\", \"ticket_id\": 123456}",
  "registered_at": "2024-02-15T10:30:45.123456"
}
```

---

## Tickets - Verify (Entry Gate)

### Request
```bash
curl -X POST http://localhost:8000/ticket/verify \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 755379222,
    "wallet": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
    "ticket_asset_id": 123456
  }'
```

### Response (200) - Valid Ticket
```json
{
  "valid": true,
  "message": "Ticket verified - Entry granted",
  "event_name": "Freshers Party 2024",
  "attendee": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
  "timestamp": "2024-02-15T10:35:20.654321",
  "entry_count": 1
}
```

### Response (403) - Already Used
```json
{
  "valid": false,
  "message": "Ticket already used",
  "used_at": "2024-02-15T10:35:20.654321"
}
```

---

## Tickets - Get QR Code (PNG)

### Request
```bash
curl -X GET "http://localhost:8000/ticket/123456/qr?event_id=755379222&wallet=C57VRWF..." \
  --output ticket.png
```

### Response (200)
Binary PNG image containing encoded QR payload

---

## Tickets - Get QR Code (JSON)

### Request
```bash
curl -X GET "http://localhost:8000/ticket/123456/qr.json?event_id=755379222&wallet=C57VRWF..."
```

### Response (200)
```json
{
  "payload": {
    "event_id": 755379222,
    "wallet": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
    "ticket_id": 123456
  },
  "payload_string": "{\"event_id\": 755379222, \"wallet\": \"C57VRWF...\", \"ticket_id\": 123456}",
  "event_id": 755379222,
  "ticket_id": 123456,
  "wallet": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4"
}
```

---

## Tickets - List User Tickets

### Request
```bash
curl "http://localhost:8000/ticket/user/C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4"
```

### Response (200)
```json
{
  "wallet": "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4",
  "tickets": [
    {
      "ticket_id": 123456,
      "event": "Freshers Party 2024",
      "purchased_at": "2024-02-15T10:30:45.123456",
      "is_used": true,
      "verified_at": "2024-02-15T10:35:20.654321"
    }
  ],
  "count": 1
}
```

---

## Treasury - Allocate Funds

### Request
```bash
curl -X POST http://localhost:8000/treasury/allocate \
  -H "Content-Type: application/json" \
  -d '{
    "signed_txn": "iqNhbXS...[base64 encoded transaction]...==",
    "amount": 50000.00,
    "club_id": "sports_club_001",
    "purpose": "Sports Day Prizes"
  }'
```

### Response (200)
```json
{
  "success": true,
  "txid": "AQZGAAA...",
  "explorer_url": "https://testnet.algoexplorer.io/tx/AQZGAAA...",
  "message": "Funds allocated successfully",
  "confirmed_round": 60432870
}
```

---

## Treasury - Get Status

### Request
```bash
curl http://localhost:8000/treasury/status
```

### Response (200)
```json
{
  "total_funds": 150000.00,
  "available": 50000.00,
  "allocated": 100000.00,
  "pending_approval": 30000.00,
  "clubs": ["sports_club_001", "cultural_club_002"]
}
```

---

## Treasury - Get Club Allocations

### Request
```bash
curl http://localhost:8000/treasury/club/sports_club_001
```

### Response (200)
```json
{
  "club_id": "sports_club_001",
  "allocations": [
    {
      "id": 1,
      "amount": 50000.00,
      "purpose": "Sports Day Prizes",
      "status": "released",
      "created_at": "2024-02-15T10:30:45.123456",
      "released_at": "2024-02-15T11:30:45.654321"
    }
  ],
  "count": 1
}
```

---

## Error Responses

### Invalid Address (400)
```json
{
  "detail": "Invalid address format"
}
```

### Not Found (404)
```json
{
  "detail": "Event not found"
}
```

### Server Error (500)
```json
{
  "detail": "Withdrawal processing failed"
}
```

### Timeout (504)
```json
{
  "detail": "Transaction confirmation timeout"
}
```

---

## Testing with Python

```python
import requests
import json

BASE_URL = "http://localhost:8000"

# Health check
response = requests.get(f"{BASE_URL}/health/")
print(response.json())

# Get vault balance
address = "C57VRWFTIRIL567HG7BFCY3DEC2QLN6TDZYPFD3AG7NZDOD2JVVYQJVCA4"
response = requests.get(f"{BASE_URL}/vault/balance/{address}")
print(response.json())

# List events
response = requests.get(f"{BASE_URL}/event/list")
print(response.json())
```

---

## Testing with JavaScript/Fetch

```javascript
// Health check
fetch('http://localhost:8000/health/')
  .then(r => r.json())
  .then(data => console.log(data));

// Get vault balance
const address = "C57VRWF...";
fetch(`http://localhost:8000/vault/balance/${address}`)
  .then(r => r.json())
  .then(data => console.log(data));

// Verify ticket
fetch('http://localhost:8000/ticket/verify', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    event_id: 755379222,
    wallet: address,
    ticket_asset_id: 123456
  })
})
.then(r => r.json())
.then(data => console.log(data));
```

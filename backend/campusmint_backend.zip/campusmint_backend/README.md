# CampusMint API - Backend Documentation

University fintech + NFT ticketing system on Algorand Testnet

## 🚀 Quick Start

### Prerequisites
- Python 3.9+
- pip or conda
- Algorand Testnet account with funded wallet
- cURL or Postman (for testing)

### Installation

```bash
# Clone repository
git clone <repo>
cd campusmint_backend

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env

# Edit .env with your configuration
nano .env
```

### Environment Setup

```env
# Algorand (leave empty for Testnet public nodes)
ALGOD_ADDRESS=https://testnet-api.algonode.cloud
INDEXER_ADDRESS=https://testnet-idx.algonode.cloud
ALGOD_TOKEN=

# Asset IDs (deployed contracts)
CINR_ASSET_ID=755378709
VAULT_APP_ID=755379222

# Admin
ADMIN_ADDRESS=<your-wallet-address>
ADMIN_MNEMONIC=<your-25-word-mnemonic>

# Database
DATABASE_URL=sqlite:///./campusmint.db
```

### Running the Server

```bash
# Development (with hot reload)
python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production (no reload)
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

Server will be available at `http://localhost:8000`

## 📚 API Documentation

### Interactive Docs
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`

## 🏗 Architecture

```
app/
├── routers/              # API endpoints
│   ├── health.py         # Health check
│   ├── vault.py          # Student savings
│   ├── event.py          # Event management
│   ├── ticket.py         # NFT tickets + QR
│   └── treasury.py       # Fund allocation
├── services/             # Business logic
│   ├── algo_client.py    # Algorand SDK wrapper
│   ├── database.py       # DB init & session
│   ├── vault_service.py  # Vault operations
│   ├── event_service.py  # Event operations
│   ├── ticket_service.py # Ticket + QR logic
│   └── treasury_service.py # Treasury operations
├── models/               # Data models
│   ├── schemas.py        # Pydantic request/response
│   └── database.py       # SQLAlchemy ORM
├── config.py            # Settings management
└── __init__.py

main.py                   # FastAPI app entry point
requirements.txt         # Python dependencies
.env.example            # Environment template
```

## 📡 API Endpoints

### Health Check
```bash
GET /health/
GET /health/ready
```

### Student Vault
```bash
# Deposit funds
POST /vault/deposit
Body: {signed_txn, amount, lock_days}

# Withdraw funds
POST /vault/withdraw
Body: {signed_txn, reason, emergency_password}

# Get balance
GET /vault/balance/{address}

# Get status
GET /vault/status/{address}
```

### Events
```bash
# Create event
POST /event/create
Body: {name, description, location, date, ticket_price, max_tickets, organizer_address}

# List events
GET /event/list?limit=20

# Get event details
GET /event/{event_id}

# Purchase ticket
POST /event/{event_id}/pay
Body: {signed_txn}
```

### Tickets
```bash
# Verify ticket (entry)
POST /ticket/verify
Body: {event_id, wallet, ticket_asset_id}

# Register ticket
POST /ticket/{event_id}/register?ticket_asset_id=...&buyer_address=...&price_paid=...

# Get QR code (PNG)
GET /ticket/{ticket_asset_id}/qr?event_id=...&wallet=...

# Get QR payload (JSON)
GET /ticket/{ticket_asset_id}/qr.json?event_id=...&wallet=...

# Get ticket info
GET /ticket/{ticket_asset_id}

# List user tickets
GET /ticket/user/{wallet}
```

### Treasury
```bash
# Allocate funds
POST /treasury/allocate
Body: {signed_txn, amount, club_id, purpose}

# Approve allocation
POST /treasury/approve/{allocation_id}?approved_by=...&by_admin=true

# Release funds
POST /treasury/release/{allocation_id}?txid=...

# Get treasury status
GET /treasury/status

# Get club allocations
GET /treasury/club/{club_id}
```

## 📝 Example Requests

### Vault Deposit
```bash
curl -X POST http://localhost:8000/vault/deposit \
  -H "Content-Type: application/json" \
  -d '{
    "signed_txn": "base64_encoded_txn",
    "amount": 5000.00,
    "lock_days": 30
  }'
```

### Verify Ticket
```bash
curl -X POST http://localhost:8000/ticket/verify \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 755379222,
    "wallet": "ALGOACCOUNT...",
    "ticket_asset_id": 123456
  }'
```

### Get QR Code
```bash
curl -X GET "http://localhost:8000/ticket/123456/qr?event_id=755379222&wallet=ALGOACCOUNT..." \
  --output ticket.png
```

## 🔄 Integration with Frontend (React Native/Expo)

### 1. Submit Signed Transaction
```javascript
// From Expo wallet integration
const signedTxnBase64 = await signTransaction(txn);

// Submit to backend
const response = await fetch('http://localhost:8000/vault/deposit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    signed_txn: signedTxnBase64,
    amount: 5000.00,
    lock_days: 30
  })
});

const result = await response.json();
console.log('Transaction:', result.txid);
console.log('Explorer:', result.explorer_url);
```

### 2. Verify Ticket from QR
```javascript
import { CameraView } from 'expo-camera';
import QRCode from 'qrcode-reader';

// After scanning QR code
const scannedData = JSON.parse(qrCodeText);

const response = await fetch('http://localhost:8000/ticket/verify', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    event_id: scannedData.event_id,
    wallet: scannedData.wallet,
    ticket_asset_id: scannedData.ticket_id
  })
});

const verification = await response.json();
if (verification.valid) {
  console.log('✅ Entry granted!');
} else {
  console.log('❌', verification.message);
}
```

### 3. Generate QR Code for Ticket
```javascript
// After ticket purchase
const response = await fetch(
  `http://localhost:8000/ticket/${ticketAssetId}/qr.json?event_id=${eventId}&wallet=${userAddress}`
);
const qrData = await response.json();

// Use payload to generate QR in app
// Or fetch PNG directly:
const imageUrl = `http://localhost:8000/ticket/${ticketAssetId}/qr?event_id=${eventId}&wallet=${userAddress}`;
```

## 🔐 Security Considerations

### Production Checklist
- [ ] Change SECRET_KEY in .env
- [ ] Restrict CORS_ORIGINS to specific domains
- [ ] Use HTTPS/TLS for all API calls
- [ ] Implement rate limiting
- [ ] Add API key authentication
- [ ] Use environment-specific configs
- [ ] Enable database encryption
- [ ] Set up proper logging/monitoring
- [ ] Implement admin verification
- [ ] Audit transaction logs

### Transaction Verification
- Always verify signed transactions on-chain
- Validate asset IDs match expected CINR
- Check wallet addresses are valid
- Confirm transaction confirmation before processing
- Log all sensitive operations

## 🗄 Database Schema

### Tables
- **events**: Event metadata
- **tickets**: NFT ticket records with QR verification
- **vault_entries**: Student savings vaults
- **treasury_allocations**: Fund allocation requests
- **transaction_logs**: Complete audit trail

## 📊 Monitoring & Logging

All operations are logged with timestamps:
```
✅ Transaction submitted: txid
✅ Database initialized
❌ Failed to connect: error
```

Check logs:
```bash
# View logs in real-time
tail -f app.log

# Search for errors
grep "❌" app.log

# Check transaction history
sqlite3 campusmint.db "SELECT * FROM transaction_logs ORDER BY created_at DESC LIMIT 10;"
```

## 🧪 Testing

### Unit Tests (coming soon)
```bash
pytest tests/ -v
```

### Manual Testing
```bash
# Health check
curl http://localhost:8000/health/

# Check database
sqlite3 campusmint.db ".tables"

# View transactions
sqlite3 campusmint.db "SELECT txn_id, type, amount, status FROM transaction_logs LIMIT 5;"
```

## 🚢 Deployment

### Docker
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Docker Compose
```yaml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: sqlite:///./campusmint.db
      ALGOD_ADDRESS: https://testnet-api.algonode.cloud
    volumes:
      - ./campusmint.db:/app/campusmint.db
```

### Cloud Deployment (Heroku)
```bash
heroku create campusmint-api
heroku config:set ALGOD_ADDRESS=https://testnet-api.algonode.cloud
git push heroku main
```

### Railway/Render
- Connect GitHub repo
- Set environment variables
- Deploy automatically

## 🤝 Contributing

1. Create feature branch
2. Make changes
3. Test locally
4. Submit PR

## 📄 License

MIT License - See LICENSE file

## 🆘 Support

- Issues: GitHub Issues
- Docs: /docs endpoint
- Email: support@campusmint.io

## 🎯 Roadmap

- [ ] User authentication system
- [ ] Email notifications
- [ ] Advanced analytics dashboard
- [ ] Multi-currency support
- [ ] Mainnet deployment
- [ ] Mobile app integration
- [ ] Admin dashboard UI
- [ ] Automated tests

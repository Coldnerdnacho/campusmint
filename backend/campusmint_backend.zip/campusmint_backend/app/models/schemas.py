"""
Pydantic models for request/response validation
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# ============================================================================
# VAULT MODELS
# ============================================================================

class VaultDepositRequest(BaseModel):
    """Student vault deposit request"""
    signed_txn: str = Field(..., description="Base64 encoded signed transaction")
    amount: float = Field(..., gt=0, description="Amount in rupees")
    lock_days: int = Field(..., gt=0, description="Days to lock funds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "signed_txn": "base64_encoded_txn_string",
                "amount": 5000.00,
                "lock_days": 30
            }
        }


class VaultWithdrawRequest(BaseModel):
    """Student vault withdrawal request"""
    signed_txn: str = Field(..., description="Base64 encoded signed transaction")
    reason: str = Field(..., description="Reason for withdrawal (emergency, goal_reached)")
    emergency_password: Optional[str] = Field(None, description="Password for emergency withdrawal")
    
    class Config:
        json_schema_extra = {
            "example": {
                "signed_txn": "base64_encoded_txn_string",
                "reason": "emergency",
                "emergency_password": "secure_password_123"
            }
        }


class VaultStatus(BaseModel):
    """Vault status response"""
    address: str
    total_saved: float
    goal_amount: float
    progress_percent: float
    unlock_timestamp: int
    locked: bool
    days_remaining: int
    emergency_available: bool
    

class VaultBalanceResponse(BaseModel):
    """Vault balance response"""
    address: str
    balance_cinr: float
    balance_usd: Optional[float] = None
    account_age_days: int
    can_withdraw: bool


# ============================================================================
# EVENT MODELS
# ============================================================================

class EventCreateRequest(BaseModel):
    """Create new event"""
    name: str = Field(..., description="Event name")
    description: str = Field(..., description="Event description")
    location: str = Field(..., description="Event location")
    date: str = Field(..., description="Event date (YYYY-MM-DD)")
    ticket_price: float = Field(..., gt=0, description="Ticket price in CINR")
    max_tickets: int = Field(..., gt=0, description="Maximum tickets")
    organizer_address: str = Field(..., description="Organizer wallet address")
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "Freshers Party 2024",
                "description": "Welcome to campus!",
                "location": "Main Auditorium",
                "date": "2024-03-15",
                "ticket_price": 500.0,
                "max_tickets": 1000,
                "organizer_address": "ALGOACCOUNT..."
            }
        }


class EventPaymentRequest(BaseModel):
    """Payment for event ticket"""
    signed_txn: str = Field(..., description="Base64 encoded signed transaction")
    event_id: int = Field(..., description="Event ID (Algorand app ID)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "signed_txn": "base64_encoded_txn",
                "event_id": 755379222
            }
        }


class EventResponse(BaseModel):
    """Event details response"""
    id: int
    name: str
    description: str
    location: str
    date: str
    ticket_price: float
    max_tickets: int
    tickets_sold: int
    organizer_address: str
    nft_asset_id: int
    created_at: datetime


# ============================================================================
# TICKET MODELS
# ============================================================================

class TicketVerifyRequest(BaseModel):
    """QR code ticket verification"""
    event_id: int = Field(..., description="Event app ID")
    wallet: str = Field(..., description="Attendee wallet address")
    ticket_asset_id: int = Field(..., description="Ticket NFT asset ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "event_id": 755379222,
                "wallet": "ALGOACCOUNT...",
                "ticket_asset_id": 123456
            }
        }


class TicketVerifyResponse(BaseModel):
    """Ticket verification response"""
    valid: bool
    message: str
    event_name: str
    attendee: str
    timestamp: datetime
    entry_count: int


class TicketQRPayload(BaseModel):
    """QR code payload structure"""
    event_id: int
    wallet: str
    ticket_id: int
    
    class Config:
        json_schema_extra = {
            "example": {
                "event_id": 755379222,
                "wallet": "ALGOACCOUNT...",
                "ticket_id": 123456
            }
        }


# ============================================================================
# TREASURY MODELS
# ============================================================================

class TreasuryAllocateRequest(BaseModel):
    """Treasury fund allocation"""
    signed_txn: str = Field(..., description="Base64 encoded signed transaction")
    amount: float = Field(..., gt=0, description="Amount in CINR")
    club_id: str = Field(..., description="Club identifier")
    purpose: str = Field(..., description="Purpose of allocation")
    
    class Config:
        json_schema_extra = {
            "example": {
                "signed_txn": "base64_encoded_txn",
                "amount": 10000.0,
                "club_id": "sports_club_001",
                "purpose": "Sports day prizes"
            }
        }


class TreasuryStatus(BaseModel):
    """Treasury status"""
    total_funds: float
    available: float
    allocated: float
    pending_approval: float
    clubs: List[str]


# ============================================================================
# TRANSACTION MODELS
# ============================================================================

class SignedTxnSubmission(BaseModel):
    """Generic signed transaction submission"""
    signed_txn: str = Field(..., description="Base64 encoded signed transaction")
    note: Optional[str] = Field(None, description="Optional note")


class TxnConfirmation(BaseModel):
    """Transaction confirmation response"""
    success: bool
    txid: str
    explorer_url: str
    message: str
    confirmed_round: Optional[int] = None


# ============================================================================
# WALLET MODELS
# ============================================================================

class WalletInfo(BaseModel):
    """Wallet information"""
    address: str
    algo_balance: float
    cinr_balance: float
    is_opted_in_cinr: bool


# ============================================================================
# ERROR MODELS
# ============================================================================

class ErrorResponse(BaseModel):
    """Error response"""
    error: str
    detail: str
    timestamp: datetime

"""
SQLAlchemy database models
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class Event(Base):
    """Event model"""
    __tablename__ = "events"
    
    id = Column(Integer, primary_key=True, index=True)
    app_id = Column(Integer, unique=True, index=True)
    name = Column(String, index=True)
    description = Column(Text)
    location = Column(String)
    date = Column(String)
    ticket_price = Column(Float)
    max_tickets = Column(Integer)
    tickets_sold = Column(Integer, default=0)
    organizer_address = Column(String, index=True)
    nft_asset_id = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Ticket(Base):
    """NFT Ticket model"""
    __tablename__ = "tickets"
    
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, index=True)  # Event app_id
    ticket_asset_id = Column(Integer, unique=True, index=True)
    buyer_address = Column(String, index=True)
    event_name = Column(String)
    price_paid = Column(Float)
    purchased_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime, nullable=True)
    entry_count = Column(Integer, default=0)
    is_used = Column(Boolean, default=False)


class VaultEntry(Base):
    """Savings vault entry"""
    __tablename__ = "vault_entries"
    
    id = Column(Integer, primary_key=True, index=True)
    address = Column(String, unique=True, index=True)
    total_deposited = Column(Float, default=0)
    goal_amount = Column(Float, nullable=True)
    lock_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    emergency_withdrawals = Column(Integer, default=0)


class TreasuryAllocation(Base):
    """Treasury allocation record"""
    __tablename__ = "treasury_allocations"
    
    id = Column(Integer, primary_key=True, index=True)
    club_id = Column(String, index=True)
    amount = Column(Float)
    purpose = Column(String)
    status = Column(String, default="pending")  # pending, approved, released
    admin_approval = Column(Boolean, default=False)
    club_lead_approval = Column(Boolean, default=False)
    approved_by = Column(String, nullable=True)
    txn_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    released_at = Column(DateTime, nullable=True)


class TransactionLog(Base):
    """Transaction history log"""
    __tablename__ = "transaction_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    txn_id = Column(String, unique=True, index=True)
    type = Column(String)  # deposit, withdraw, payment, allocation
    address = Column(String, index=True)
    amount = Column(Float)
    status = Column(String)  # pending, confirmed, failed
    confirmed_round = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    confirmed_at = Column(DateTime, nullable=True)
    note = Column(Text, nullable=True)

"""
Event API routes - event management and ticket sales
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.models.schemas import (
    EventCreateRequest,
    EventPaymentRequest,
    EventResponse,
    TxnConfirmation
)
from app.models.database import get_db
from app.services.event_service import EventService
from app.services.algo_client import AlgorandClient

router = APIRouter()


def get_event_service(
    db: Session = Depends(get_db),
) -> EventService:
    """Dependency to get event service"""
    from main import app
    algo_client = app.state.algo_client
    return EventService(algo_client, db)


@router.post("/create")
async def create_event(
    request: EventCreateRequest,
    service: EventService = Depends(get_event_service)
):
    """
    Create new event (admin only)
    
    Request body:
    - name: Event name
    - description: Event description
    - location: Location
    - date: Event date (YYYY-MM-DD)
    - ticket_price: Ticket price in CINR
    - max_tickets: Maximum tickets
    - organizer_address: Organizer wallet address
    """
    result = service.create_event(
        app_id=0,  # Will be set from contract deployment
        name=request.name,
        description=request.description,
        location=request.location,
        date=request.date,
        ticket_price=request.ticket_price,
        max_tickets=request.max_tickets,
        organizer_address=request.organizer_address
    )
    
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    
    return result


@router.get("/list")
async def list_events(
    limit: int = 20,
    service: EventService = Depends(get_event_service)
):
    """
    List all active events
    
    Query parameters:
    - limit: Maximum events to return (default: 20)
    """
    events = service.list_events(limit=limit)
    return {"events": events, "count": len(events)}


@router.get("/{event_id}")
async def get_event(
    event_id: int,
    service: EventService = Depends(get_event_service)
):
    """
    Get event details
    
    Path parameters:
    - event_id: Event app ID
    """
    event = service.get_event(event_id)
    
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    return event


@router.post("/{event_id}/pay", response_model=TxnConfirmation)
async def pay_for_ticket(
    event_id: int,
    request: EventPaymentRequest,
    service: EventService = Depends(get_event_service)
):
    """
    Purchase event ticket
    
    Path parameters:
    - event_id: Event app ID
    
    Request body:
    - signed_txn: Base64 encoded signed transaction
    """
    # Verify event exists
    event = service.get_event(event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    # Submit transaction
    submit_result = service.algo_client.submit_transaction(request.signed_txn)
    
    if not submit_result.get("success"):
        raise HTTPException(status_code=400, detail=submit_result.get("error"))
    
    txid = submit_result["txid"]
    
    # Wait for confirmation
    confirmation = service.algo_client.wait_for_confirmation(txid)
    
    if not confirmation:
        raise HTTPException(status_code=504, detail="Transaction confirmation timeout")
    
    # Get buyer address
    pending = service.algo_client.algod_client.pending_transaction_info(txid)
    buyer = pending.get("txn", {}).get("txn", {}).get("snd", "")
    
    if buyer:
        result = await service.process_ticket_purchase(
            app_id=event_id,
            buyer_address=buyer,
            txid=txid
        )
        
        if result.get("success"):
            return TxnConfirmation(
                success=True,
                txid=txid,
                explorer_url=submit_result["explorer_url"],
                message=f"Ticket purchased for {event.get('name', 'Event')}",
                confirmed_round=confirmation.get("confirmed-round")
            )
    
    raise HTTPException(status_code=500, detail="Payment processing failed")

"""
Vault API routes - student savings management
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.models.schemas import (
    VaultDepositRequest,
    VaultWithdrawRequest,
    VaultStatus,
    VaultBalanceResponse,
    TxnConfirmation
)
from app.models.database import get_db
from app.services.vault_service import VaultService
from app.services.algo_client import AlgorandClient

router = APIRouter()


def get_vault_service(
    db: Session = Depends(get_db),
) -> VaultService:
    """Dependency to get vault service"""
    from main import app
    algo_client = app.state.algo_client
    return VaultService(algo_client, db)


@router.post("/deposit", response_model=TxnConfirmation)
async def deposit(
    request: VaultDepositRequest,
    service: VaultService = Depends(get_vault_service)
):
    """
    Deposit funds to savings vault
    
    Request body:
    - signed_txn: Base64 encoded signed transaction
    - amount: Amount in CINR (e.g., 5000.00)
    - lock_days: Days to lock funds (e.g., 30)
    """
    # Submit transaction to blockchain
    submit_result = service.algo_client.submit_transaction(request.signed_txn)
    
    if not submit_result.get("success"):
        raise HTTPException(status_code=400, detail=submit_result.get("error"))
    
    txid = submit_result["txid"]
    
    # Wait for confirmation
    confirmation = service.algo_client.wait_for_confirmation(txid)
    
    if not confirmation:
        raise HTTPException(status_code=504, detail="Transaction confirmation timeout")
    
    # Get sender address from pending info
    pending = service.algo_client.algod_client.pending_transaction_info(txid)
    address = pending.get("txn", {}).get("txn", {}).get("snd", "")
    
    # Process deposit
    if address:
        result = await service.process_deposit(
            address=address,
            amount=request.amount,
            lock_days=request.lock_days,
            txid=txid
        )
        
        if result.get("success"):
            return TxnConfirmation(
                success=True,
                txid=txid,
                explorer_url=submit_result["explorer_url"],
                message="Deposit successful",
                confirmed_round=confirmation.get("confirmed-round")
            )
    
    raise HTTPException(status_code=500, detail="Deposit processing failed")


@router.post("/withdraw", response_model=TxnConfirmation)
async def withdraw(
    request: VaultWithdrawRequest,
    service: VaultService = Depends(get_vault_service)
):
    """
    Withdraw from savings vault
    
    Request body:
    - signed_txn: Base64 encoded signed transaction
    - reason: "normal" or "emergency"
    - emergency_password: Required if reason is "emergency"
    """
    # Submit transaction
    submit_result = service.algo_client.submit_transaction(request.signed_txn)
    
    if not submit_result.get("success"):
        raise HTTPException(status_code=400, detail=submit_result.get("error"))
    
    txid = submit_result["txid"]
    
    # Wait for confirmation
    confirmation = service.algo_client.wait_for_confirmation(txid)
    
    if not confirmation:
        raise HTTPException(status_code=504, detail="Transaction confirmation timeout")
    
    # Get sender address
    pending = service.algo_client.algod_client.pending_transaction_info(txid)
    address = pending.get("txn", {}).get("txn", {}).get("snd", "")
    
    if address:
        result = await service.process_withdrawal(
            address=address,
            reason=request.reason,
            txid=txid,
            emergency_password=request.emergency_password
        )
        
        if result.get("success"):
            return TxnConfirmation(
                success=True,
                txid=txid,
                explorer_url=submit_result["explorer_url"],
                message=result.get("message", "Withdrawal successful"),
                confirmed_round=confirmation.get("confirmed-round")
            )
    
    raise HTTPException(status_code=500, detail="Withdrawal processing failed")


@router.get("/balance/{address}", response_model=VaultBalanceResponse)
async def get_balance(
    address: str,
    service: VaultService = Depends(get_vault_service)
):
    """
    Get vault balance and status for an address
    
    Path parameters:
    - address: Algorand wallet address
    """
    if not service.algo_client.is_address_valid(address):
        raise HTTPException(status_code=400, detail="Invalid address format")
    
    status = service.get_vault_status(address)
    
    if "error" in status:
        raise HTTPException(status_code=500, detail=status["error"])
    
    return VaultBalanceResponse(**status)


@router.get("/status/{address}", response_model=VaultStatus)
async def get_status(
    address: str,
    service: VaultService = Depends(get_vault_service)
):
    """
    Get detailed vault status
    
    Path parameters:
    - address: Algorand wallet address
    """
    if not service.algo_client.is_address_valid(address):
        raise HTTPException(status_code=400, detail="Invalid address format")
    
    vault = service.get_or_create_vault(address)
    
    from datetime import datetime
    now = datetime.utcnow()
    locked = vault.lock_until and now < vault.lock_until
    days_remaining = 0
    
    if vault.lock_until:
        delta = vault.lock_until - now
        days_remaining = max(0, delta.days)
    
    return VaultStatus(
        address=address,
        total_saved=vault.total_deposited,
        goal_amount=vault.goal_amount or 0,
        progress_percent=0,
        unlock_timestamp=int(vault.lock_until.timestamp()) if vault.lock_until else 0,
        locked=locked,
        days_remaining=days_remaining,
        emergency_available=vault.emergency_withdrawals < 2
    )

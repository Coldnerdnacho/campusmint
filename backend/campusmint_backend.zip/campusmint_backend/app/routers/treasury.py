"""
Treasury API routes - fund allocation and management
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.models.schemas import (
    TreasuryAllocateRequest,
    TreasuryStatus,
    TxnConfirmation
)
from app.models.database import get_db
from app.services.treasury_service import TreasuryService
from app.services.algo_client import AlgorandClient

router = APIRouter()


def get_treasury_service(
    db: Session = Depends(get_db),
) -> TreasuryService:
    """Dependency to get treasury service"""
    from main import app
    algo_client = app.state.algo_client
    return TreasuryService(algo_client, db)


@router.post("/allocate", response_model=TxnConfirmation)
async def allocate_funds(
    request: TreasuryAllocateRequest,
    service: TreasuryService = Depends(get_treasury_service)
):
    """
    Allocate treasury funds to a club
    
    Request body:
    - signed_txn: Base64 encoded signed transaction
    - amount: Amount in CINR
    - club_id: Club identifier
    - purpose: Purpose of allocation
    """
    # Submit transaction
    submit_result = service.algo_client.submit_transaction(request.signed_txn)
    
    if not submit_result.get("success"):
        raise HTTPException(status_code=400, detail=submit_result.get("error"))
    
    txid = submit_result["txid"]
    
    # Wait for confirmation
    confirmation = service.algo_client.wait_for_confirmation(txid)
    
    if not confirmation:
        raise HTTPException(status_code=504, detail="Transaction confirmation timeout")
    
    # Process allocation
    result = service.allocate_funds(
        club_id=request.club_id,
        amount=request.amount,
        purpose=request.purpose,
        txid=txid
    )
    
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    
    return TxnConfirmation(
        success=True,
        txid=txid,
        explorer_url=submit_result["explorer_url"],
        message="Funds allocated successfully",
        confirmed_round=confirmation.get("confirmed-round")
    )


@router.post("/approve/{allocation_id}")
async def approve_allocation(
    allocation_id: int,
    approved_by: str,
    by_admin: bool = False,
    service: TreasuryService = Depends(get_treasury_service)
):
    """
    Approve fund allocation
    
    Path parameters:
    - allocation_id: Allocation ID
    
    Query parameters:
    - approved_by: Approver address
    - by_admin: True if admin approval
    """
    result = service.approve_allocation(
        allocation_id=allocation_id,
        approved_by=approved_by,
        by_admin=by_admin
    )
    
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    
    return result


@router.post("/release/{allocation_id}")
async def release_funds(
    allocation_id: int,
    txid: str,
    service: TreasuryService = Depends(get_treasury_service)
):
    """
    Release funds for approved allocation
    
    Path parameters:
    - allocation_id: Allocation ID
    
    Query parameters:
    - txid: Release transaction ID
    """
    result = await service.release_funds(
        allocation_id=allocation_id,
        txid=txid
    )
    
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    
    return result


@router.get("/status", response_model=TreasuryStatus)
async def get_treasury_status(
    service: TreasuryService = Depends(get_treasury_service)
):
    """
    Get treasury status
    """
    status = service.get_treasury_status()
    
    if "error" in status:
        raise HTTPException(status_code=500, detail=status.get("error"))
    
    return TreasuryStatus(**status)


@router.get("/club/{club_id}")
async def get_club_allocations(
    club_id: str,
    service: TreasuryService = Depends(get_treasury_service)
):
    """
    Get allocations for a specific club
    
    Path parameters:
    - club_id: Club identifier
    """
    allocations = service.get_club_allocations(club_id)
    
    return {
        "club_id": club_id,
        "allocations": allocations,
        "count": len(allocations)
    }

"""
Ticket API routes - NFT ticket management and QR verification
"""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session
import json

from app.models.schemas import (
    TicketVerifyRequest,
    TicketVerifyResponse,
    TicketQRPayload
)
from app.models.database import get_db
from app.services.ticket_service import TicketService
from app.services.algo_client import AlgorandClient

router = APIRouter()


def get_ticket_service(
    db: Session = Depends(get_db),
) -> TicketService:
    """Dependency to get ticket service"""
    from main import app
    algo_client = app.state.algo_client
    return TicketService(algo_client, db)


@router.post("/verify", response_model=TicketVerifyResponse)
async def verify_ticket(
    request: TicketVerifyRequest,
    service: TicketService = Depends(get_ticket_service)
):
    """
    Verify ticket for entry (scan QR code)
    
    Request body:
    - event_id: Event app ID
    - wallet: Attendee wallet address
    - ticket_asset_id: Ticket NFT asset ID
    """
    result = await service.verify_ticket(
        event_id=request.event_id,
        wallet=request.wallet,
        ticket_asset_id=request.ticket_asset_id
    )
    
    if not result.get("valid"):
        raise HTTPException(
            status_code=403,
            detail=result.get("message", "Ticket verification failed")
        )
    
    return TicketVerifyResponse(
        valid=result.get("valid", False),
        message=result.get("message", ""),
        event_name=result.get("event_name", ""),
        attendee=result.get("attendee", ""),
        timestamp=result.get("verified_at"),
        entry_count=result.get("entry_count", 0)
    )


@router.post("/{event_id}/register")
async def register_ticket(
    event_id: int,
    ticket_asset_id: int,
    buyer_address: str,
    price_paid: float,
    service: TicketService = Depends(get_ticket_service)
):
    """
    Register purchased ticket
    
    Query parameters:
    - event_id: Event app ID
    - ticket_asset_id: Ticket NFT asset ID
    - buyer_address: Buyer wallet address
    - price_paid: Price in CINR
    """
    # This is called after successful payment
    result = await service.register_ticket(
        event_id=event_id,
        ticket_asset_id=ticket_asset_id,
        buyer_address=buyer_address,
        event_name="Event",  # Should come from event service
        price_paid=price_paid,
        txid="pending"  # Should come from payment processing
    )
    
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error"))
    
    return {
        "success": True,
        "ticket_asset_id": result["ticket_asset_id"],
        "qr_payload": result["qr_payload"],
        "registered_at": result["registered_at"]
    }


@router.get("/{ticket_asset_id}/qr")
async def get_qr_code(
    ticket_asset_id: int,
    event_id: int,
    wallet: str,
    service: TicketService = Depends(get_ticket_service)
):
    """
    Get QR code for ticket
    
    Query parameters:
    - ticket_asset_id: Ticket asset ID
    - event_id: Event app ID
    - wallet: Attendee wallet
    
    Returns:
    - PNG image of QR code
    """
    # Create QR payload
    payload = service.create_qr_payload(event_id, wallet, ticket_asset_id)
    
    # Generate QR code
    qr_bytes = service.generate_qr_code(payload)
    
    if not qr_bytes:
        raise HTTPException(status_code=500, detail="QR code generation failed")
    
    return Response(
        content=qr_bytes,
        media_type="image/png",
        headers={"Content-Disposition": f"attachment; filename=ticket_{ticket_asset_id}.png"}
    )


@router.get("/{ticket_asset_id}/qr.json")
async def get_qr_payload_json(
    ticket_asset_id: int,
    event_id: int,
    wallet: str,
    service: TicketService = Depends(get_ticket_service)
):
    """
    Get QR code payload as JSON
    
    Query parameters:
    - ticket_asset_id: Ticket asset ID
    - event_id: Event app ID
    - wallet: Attendee wallet
    """
    payload = service.create_qr_payload(event_id, wallet, ticket_asset_id)
    
    return {
        "payload": json.loads(payload),
        "payload_string": payload,
        "event_id": event_id,
        "ticket_id": ticket_asset_id,
        "wallet": wallet
    }


@router.get("/{ticket_asset_id}")
async def get_ticket_info(
    ticket_asset_id: int,
    service: TicketService = Depends(get_ticket_service)
):
    """
    Get ticket information
    
    Path parameters:
    - ticket_asset_id: Ticket asset ID
    """
    info = service.get_ticket_info(ticket_asset_id)
    
    if not info:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    return info


@router.get("/user/{wallet}")
async def list_user_tickets(
    wallet: str,
    service: TicketService = Depends(get_ticket_service)
):
    """
    List all tickets for a user
    
    Path parameters:
    - wallet: Attendee wallet address
    """
    tickets = service.list_user_tickets(wallet)
    
    return {
        "wallet": wallet,
        "tickets": tickets,
        "count": len(tickets)
    }

"""
Ticket service - manages NFT tickets and QR verification
"""

import logging
import json
import qrcode
from io import BytesIO
from datetime import datetime
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any

from app.config import settings
from app.models.database import Ticket, Event
from app.models.schemas import TicketQRPayload
from app.services.algo_client import AlgorandClient

logger = logging.getLogger(__name__)


class TicketService:
    """NFT Ticket management"""
    
    def __init__(self, algo_client: AlgorandClient, db: Session):
        self.algo_client = algo_client
        self.db = db
    
    def create_qr_payload(
        self,
        event_id: int,
        wallet: str,
        ticket_asset_id: int
    ) -> str:
        """
        Create QR code payload (JSON)
        
        Args:
            event_id: Event app ID
            wallet: Attendee wallet
            ticket_asset_id: Ticket NFT asset ID
        
        Returns:
            JSON payload string
        """
        payload = {
            "event_id": event_id,
            "wallet": wallet,
            "ticket_id": ticket_asset_id
        }
        return json.dumps(payload)
    
    def generate_qr_code(self, payload: str) -> bytes:
        """
        Generate QR code image from payload
        
        Args:
            payload: JSON payload string
        
        Returns:
            PNG bytes
        """
        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(payload)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert to bytes
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            return buffer.getvalue()
        
        except Exception as e:
            logger.error(f"❌ QR generation failed: {e}")
            return b""
    
    async def register_ticket(
        self,
        event_id: int,
        ticket_asset_id: int,
        buyer_address: str,
        event_name: str,
        price_paid: float,
        txid: str
    ) -> Dict[str, Any]:
        """
        Register purchased ticket in database
        
        Args:
            event_id: Event app ID
            ticket_asset_id: NFT asset ID
            buyer_address: Buyer wallet
            event_name: Event name
            price_paid: Price in CINR
            txid: Purchase transaction ID
        
        Returns:
            Registration result with QR code
        """
        try:
            # Check if ticket already exists
            existing = self.db.query(Ticket).filter(
                Ticket.ticket_asset_id == ticket_asset_id
            ).first()
            
            if existing:
                return {"success": False, "error": "Ticket already registered"}
            
            # Create ticket record
            ticket = Ticket(
                event_id=event_id,
                ticket_asset_id=ticket_asset_id,
                buyer_address=buyer_address,
                event_name=event_name,
                price_paid=price_paid
            )
            
            self.db.add(ticket)
            self.db.commit()
            
            # Generate QR code
            qr_payload = self.create_qr_payload(
                event_id,
                buyer_address,
                ticket_asset_id
            )
            qr_bytes = self.generate_qr_code(qr_payload)
            
            logger.info(f"✅ Ticket registered: {ticket_asset_id} for {buyer_address}")
            
            return {
                "success": True,
                "ticket_asset_id": ticket_asset_id,
                "event_name": event_name,
                "buyer": buyer_address,
                "qr_payload": qr_payload,
                "qr_code": qr_bytes.hex(),  # Convert to hex for JSON
                "registered_at": ticket.purchased_at.isoformat()
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Ticket registration failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def verify_ticket(
        self,
        event_id: int,
        wallet: str,
        ticket_asset_id: int
    ) -> Dict[str, Any]:
        """
        Verify ticket for entry
        
        Args:
            event_id: Event app ID
            wallet: Attendee wallet
            ticket_asset_id: Ticket asset ID
        
        Returns:
            Verification result
        """
        try:
            # Find ticket
            ticket = self.db.query(Ticket).filter(
                Ticket.event_id == event_id,
                Ticket.ticket_asset_id == ticket_asset_id,
                Ticket.buyer_address == wallet
            ).first()
            
            if not ticket:
                return {
                    "valid": False,
                    "message": "Ticket not found",
                    "event_id": event_id
                }
            
            # Check if already used
            if ticket.is_used:
                return {
                    "valid": False,
                    "message": "Ticket already used",
                    "used_at": ticket.verified_at.isoformat()
                }
            
            # Mark as used
            ticket.is_used = True
            ticket.verified_at = datetime.utcnow()
            ticket.entry_count += 1
            
            self.db.commit()
            
            # Get event details
            event = self.db.query(Event).filter(
                Event.app_id == event_id
            ).first()
            
            logger.info(f"✅ Ticket verified: {ticket_asset_id} for {wallet}")
            
            return {
                "valid": True,
                "message": "Ticket verified - Entry granted",
                "event_name": ticket.event_name,
                "attendee": wallet,
                "ticket_id": ticket_asset_id,
                "entry_count": ticket.entry_count,
                "verified_at": ticket.verified_at.isoformat()
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Ticket verification failed: {e}")
            return {
                "valid": False,
                "message": f"Verification error: {str(e)}"
            }
    
    def get_ticket_info(self, ticket_asset_id: int) -> Optional[Dict[str, Any]]:
        """Get ticket information"""
        try:
            ticket = self.db.query(Ticket).filter(
                Ticket.ticket_asset_id == ticket_asset_id
            ).first()
            
            if not ticket:
                return None
            
            return {
                "ticket_id": ticket.ticket_asset_id,
                "event_name": ticket.event_name,
                "buyer": ticket.buyer_address,
                "price_paid": ticket.price_paid,
                "purchased_at": ticket.purchased_at.isoformat(),
                "verified_at": ticket.verified_at.isoformat() if ticket.verified_at else None,
                "is_used": ticket.is_used,
                "entry_count": ticket.entry_count
            }
        
        except Exception as e:
            logger.error(f"❌ Failed to get ticket info: {e}")
            return None
    
    def list_user_tickets(self, address: str) -> list:
        """List all tickets for a user"""
        try:
            tickets = self.db.query(Ticket).filter(
                Ticket.buyer_address == address
            ).order_by(Ticket.purchased_at.desc()).all()
            
            return [
                {
                    "ticket_id": t.ticket_asset_id,
                    "event": t.event_name,
                    "purchased_at": t.purchased_at.isoformat(),
                    "is_used": t.is_used,
                    "verified_at": t.verified_at.isoformat() if t.verified_at else None
                }
                for t in tickets
            ]
        
        except Exception as e:
            logger.error(f"❌ Failed to list tickets: {e}")
            return []

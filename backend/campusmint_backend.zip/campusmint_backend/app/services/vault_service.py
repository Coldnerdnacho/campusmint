"""
Vault service - manages student savings and time-locked withdrawals
"""

import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any

from app.config import settings
from app.models.database import VaultEntry, TransactionLog
from app.services.algo_client import AlgorandClient

logger = logging.getLogger(__name__)


class VaultService:
    """Student vault operations"""
    
    def __init__(self, algo_client: AlgorandClient, db: Session):
        self.algo_client = algo_client
        self.db = db
    
    def get_or_create_vault(self, address: str) -> VaultEntry:
        """Get or create vault entry for address"""
        vault = self.db.query(VaultEntry).filter(
            VaultEntry.address == address
        ).first()
        
        if not vault:
            vault = VaultEntry(address=address)
            self.db.add(vault)
            self.db.commit()
            logger.info(f"✅ Created new vault for {address}")
        
        return vault
    
    async def process_deposit(
        self,
        address: str,
        amount: float,
        lock_days: int,
        txid: str
    ) -> Dict[str, Any]:
        """
        Process vault deposit
        
        Args:
            address: User address
            amount: Amount in CINR
            lock_days: Days to lock
            txid: Transaction ID
        
        Returns:
            Processing result
        """
        try:
            # Validate address
            if not self.algo_client.is_address_valid(address):
                return {"success": False, "error": "Invalid address"}
            
            # Get or create vault
            vault = self.get_or_create_vault(address)
            
            # Update vault
            vault.total_deposited += amount
            lock_until = datetime.utcnow() + timedelta(days=lock_days)
            vault.lock_until = lock_until
            vault.updated_at = datetime.utcnow()
            
            # Log transaction
            log = TransactionLog(
                txn_id=txid,
                type="deposit",
                address=address,
                amount=amount,
                status="confirmed",
                note=f"Locked for {lock_days} days"
            )
            
            self.db.add(log)
            self.db.commit()
            
            logger.info(f"✅ Deposit processed for {address}: {amount} CINR")
            
            return {
                "success": True,
                "total_saved": vault.total_deposited,
                "unlock_date": lock_until.isoformat(),
                "txid": txid
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Deposit processing failed: {e}")
            return {"success": False, "error": str(e)}
    
    def get_vault_status(self, address: str) -> Dict[str, Any]:
        """Get vault status for address"""
        try:
            vault = self.get_or_create_vault(address)
            
            now = datetime.utcnow()
            locked = vault.lock_until and now < vault.lock_until
            
            days_remaining = 0
            if vault.lock_until:
                delta = vault.lock_until - now
                days_remaining = max(0, delta.days)
            
            # Get CINR balance from blockchain
            cinr_balance = self.algo_client.check_asset_balance(
                address,
                settings.cinr_asset_id
            )
            cinr_balance = cinr_balance / (10 ** settings.cinr_decimals)
            
            return {
                "address": address,
                "total_saved": vault.total_deposited,
                "balance_cinr": cinr_balance,
                "locked": locked,
                "unlock_date": vault.lock_until.isoformat() if vault.lock_until else None,
                "days_remaining": days_remaining,
                "can_withdraw": not locked
            }
        
        except Exception as e:
            logger.error(f"❌ Failed to get vault status: {e}")
            return {
                "address": address,
                "error": str(e)
            }
    
    async def process_withdrawal(
        self,
        address: str,
        reason: str,
        txid: str,
        emergency_password: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process vault withdrawal
        
        Args:
            address: User address
            reason: "normal" or "emergency"
            txid: Transaction ID
            emergency_password: Password for emergency withdrawal
        
        Returns:
            Processing result
        """
        try:
            vault = self.get_or_create_vault(address)
            
            # Validate withdrawal
            if reason == "normal":
                if vault.lock_until and datetime.utcnow() < vault.lock_until:
                    return {
                        "success": False,
                        "error": "Funds still locked",
                        "unlock_date": vault.lock_until.isoformat()
                    }
            
            elif reason == "emergency":
                if not emergency_password:
                    return {"success": False, "error": "Emergency password required"}
                
                # In production: verify password hash
                # For MVP: simple validation
                vault.emergency_withdrawals += 1
            
            # Reset vault
            vault.total_deposited = 0
            vault.lock_until = None
            vault.updated_at = datetime.utcnow()
            
            # Log transaction
            log = TransactionLog(
                txn_id=txid,
                type="withdraw",
                address=address,
                status="confirmed",
                note=f"Withdrawal reason: {reason}"
            )
            
            self.db.add(log)
            self.db.commit()
            
            logger.info(f"✅ Withdrawal processed for {address}: {reason}")
            
            return {
                "success": True,
                "message": f"{reason.capitalize()} withdrawal processed",
                "txid": txid
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Withdrawal processing failed: {e}")
            return {"success": False, "error": str(e)}

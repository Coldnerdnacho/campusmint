"""
Algorand SDK wrapper and transaction utilities
"""

import logging
import base64
from typing import Optional, Dict, Any
from algosdk.v2client import algod, indexer
from algosdk.transaction import Transaction
from algosdk.encoding import decode_address

from app.config import settings

logger = logging.getLogger(__name__)


class AlgorandClient:
    """Algorand client wrapper"""
    
    def __init__(self):
        """Initialize Algorand clients"""
        self.algod_client = algod.AlgodClient(
            settings.algod_token or "",
            settings.algod_address
        )
        self.indexer_client = indexer.IndexerClient(
            settings.algod_token or "",
            settings.indexer_address
        )
        self._verify_connection()
    
    def _verify_connection(self):
        """Verify connection to Algorand"""
        try:
            status = self.algod_client.status()
            logger.info(f"✅ Algorand connected. Current round: {status['last-round']}")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Algorand: {e}")
            raise
    
    def submit_transaction(self, signed_txn_str: str) -> Dict[str, Any]:
        """
        Submit a signed transaction to the network
        
        Args:
            signed_txn_str: Base64 encoded signed transaction
        
        Returns:
            Dict with transaction ID and confirmation details
        """
        try:
            # Decode base64
            txn_bytes = base64.b64decode(signed_txn_str)
            
            # Submit to network
            txid = self.algod_client.send_transaction(txn_bytes)
            logger.info(f"📤 Transaction submitted: {txid}")
            
            return {
                "success": True,
                "txid": txid,
                "explorer_url": f"https://testnet.algoexplorer.io/tx/{txid}"
            }
        except Exception as e:
            logger.error(f"❌ Transaction submission failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def wait_for_confirmation(self, txid: str, max_rounds: int = 10) -> Optional[Dict]:
        """
        Wait for transaction confirmation
        
        Args:
            txid: Transaction ID
            max_rounds: Maximum rounds to wait
        
        Returns:
            Confirmed transaction info or None
        """
        try:
            confirmed_info = self.algod_client.pending_transaction_info(txid)
            
            # Check if confirmed
            if confirmed_info.get("confirmed-round", 0) > 0:
                logger.info(f"✅ Transaction confirmed: {txid}")
                return confirmed_info
            
            logger.warning(f"⏳ Transaction still pending: {txid}")
            return None
            
        except Exception as e:
            logger.error(f"❌ Error checking confirmation: {e}")
            return None
    
    def get_account_info(self, address: str) -> Optional[Dict]:
        """Get account information"""
        try:
            return self.algod_client.account_info(address)
        except Exception as e:
            logger.error(f"❌ Failed to get account info: {e}")
            return None
    
    def get_asset_info(self, asset_id: int) -> Optional[Dict]:
        """Get asset information"""
        try:
            return self.algod_client.asset_info(asset_id)
        except Exception as e:
            logger.error(f"❌ Failed to get asset info: {e}")
            return None
    
    def get_app_state(self, app_id: int) -> Optional[Dict]:
        """Get application global state"""
        try:
            app_info = self.algod_client.application_info(app_id)
            return app_info.get("params", {}).get("global-state", {})
        except Exception as e:
            logger.error(f"❌ Failed to get app state: {e}")
            return None
    
    def get_app_local_state(self, address: str, app_id: int) -> Optional[Dict]:
        """Get application local state for an account"""
        try:
            info = self.algod_client.account_application_info(address, app_id)
            return info.get("app-local-state", {})
        except Exception as e:
            logger.debug(f"⚠️ No local state for {address} in app {app_id}")
            return None
    
    def check_asset_balance(self, address: str, asset_id: int) -> float:
        """
        Check balance of an asset for an account
        
        Returns:
            Balance in smallest units
        """
        try:
            account_info = self.get_account_info(address)
            if not account_info:
                return 0.0
            
            for asset in account_info.get("assets", []):
                if asset["asset-id"] == asset_id:
                    return float(asset["amount"])
            
            return 0.0
        except Exception as e:
            logger.error(f"❌ Failed to check asset balance: {e}")
            return 0.0
    
    def is_address_valid(self, address: str) -> bool:
        """Validate Algorand address format"""
        try:
            decode_address(address)
            return True
        except Exception:
            return False
    
    def get_suggested_params(self) -> Optional[Dict]:
        """Get suggested transaction parameters"""
        try:
            return self.algod_client.suggested_params()
        except Exception as e:
            logger.error(f"❌ Failed to get suggested params: {e}")
            return None
    
    def lookup_transaction(self, txid: str) -> Optional[Dict]:
        """Look up transaction in indexer"""
        try:
            result = self.indexer_client.transaction(txid)
            return result.get("transaction")
        except Exception as e:
            logger.debug(f"⚠️ Transaction lookup failed: {e}")
            return None
    
    def search_account_transactions(self, address: str, limit: int = 10) -> list:
        """Search account transactions"""
        try:
            result = self.indexer_client.search_transactions(
                address_string=address,
                limit=limit
            )
            return result.get("transactions", [])
        except Exception as e:
            logger.error(f"❌ Failed to search transactions: {e}")
            return []

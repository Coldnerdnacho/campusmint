"""
Event service - manages events and ticket sales
"""

import logging
from datetime import datetime
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any

from app.config import settings
from app.models.database import Event, TransactionLog
from app.services.algo_client import AlgorandClient

logger = logging.getLogger(__name__)


class EventService:
    """Event management operations"""
    
    def __init__(self, algo_client: AlgorandClient, db: Session):
        self.algo_client = algo_client
        self.db = db
    
    def create_event(
        self,
        app_id: int,
        name: str,
        description: str,
        location: str,
        date: str,
        ticket_price: float,
        max_tickets: int,
        organizer_address: str,
        nft_asset_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Create new event
        
        Args:
            app_id: Algorand app ID for event contract
            name: Event name
            description: Event description
            location: Location
            date: Event date (YYYY-MM-DD)
            ticket_price: Ticket price in CINR
            max_tickets: Maximum tickets available
            organizer_address: Organizer wallet
            nft_asset_id: NFT asset ID for tickets
        
        Returns:
            Created event details
        """
        try:
            # Check if event already exists
            existing = self.db.query(Event).filter(
                Event.app_id == app_id
            ).first()
            
            if existing:
                return {"success": False, "error": "Event already exists"}
            
            # Create event
            event = Event(
                app_id=app_id,
                name=name,
                description=description,
                location=location,
                date=date,
                ticket_price=ticket_price,
                max_tickets=max_tickets,
                organizer_address=organizer_address,
                nft_asset_id=nft_asset_id
            )
            
            self.db.add(event)
            self.db.commit()
            
            logger.info(f"✅ Event created: {name} (App ID: {app_id})")
            
            return {
                "success": True,
                "event_id": app_id,
                "name": name,
                "created_at": event.created_at.isoformat()
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Event creation failed: {e}")
            return {"success": False, "error": str(e)}
    
    def get_event(self, app_id: int) -> Optional[Dict[str, Any]]:
        """Get event details"""
        try:
            event = self.db.query(Event).filter(
                Event.app_id == app_id
            ).first()
            
            if not event:
                return None
            
            return {
                "id": app_id,
                "name": event.name,
                "description": event.description,
                "location": event.location,
                "date": event.date,
                "ticket_price": event.ticket_price,
                "max_tickets": event.max_tickets,
                "tickets_sold": event.tickets_sold,
                "available_tickets": max(0, event.max_tickets - event.tickets_sold),
                "organizer": event.organizer_address,
                "nft_asset_id": event.nft_asset_id,
                "created_at": event.created_at.isoformat()
            }
        
        except Exception as e:
            logger.error(f"❌ Failed to get event: {e}")
            return None
    
    def list_events(self, limit: int = 20) -> list:
        """List all active events"""
        try:
            events = self.db.query(Event).order_by(
                Event.created_at.desc()
            ).limit(limit).all()
            
            return [
                {
                    "id": e.app_id,
                    "name": e.name,
                    "date": e.date,
                    "location": e.location,
                    "tickets_sold": e.tickets_sold,
                    "available": max(0, e.max_tickets - e.tickets_sold),
                    "organizer": e.organizer_address
                }
                for e in events
            ]
        
        except Exception as e:
            logger.error(f"❌ Failed to list events: {e}")
            return []
    
    async def process_ticket_purchase(
        self,
        app_id: int,
        buyer_address: str,
        txid: str
    ) -> Dict[str, Any]:
        """
        Process ticket purchase
        
        Args:
            app_id: Event app ID
            buyer_address: Buyer wallet address
            txid: Transaction ID
        
        Returns:
            Purchase result
        """
        try:
            event = self.db.query(Event).filter(
                Event.app_id == app_id
            ).first()
            
            if not event:
                return {"success": False, "error": "Event not found"}
            
            # Check availability
            if event.tickets_sold >= event.max_tickets:
                return {"success": False, "error": "No tickets available"}
            
            # Update event
            event.tickets_sold += 1
            event.updated_at = datetime.utcnow()
            
            # Log transaction
            log = TransactionLog(
                txn_id=txid,
                type="payment",
                address=buyer_address,
                amount=event.ticket_price,
                status="confirmed",
                note=f"Ticket purchase for {event.name}"
            )
            
            self.db.add(log)
            self.db.commit()
            
            logger.info(f"✅ Ticket purchased: {buyer_address} for {event.name}")
            
            return {
                "success": True,
                "event_name": event.name,
                "buyer": buyer_address,
                "price": event.ticket_price,
                "tickets_remaining": max(0, event.max_tickets - event.tickets_sold),
                "txid": txid,
                "nft_asset_id": event.nft_asset_id
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Ticket purchase processing failed: {e}")
            return {"success": False, "error": str(e)}

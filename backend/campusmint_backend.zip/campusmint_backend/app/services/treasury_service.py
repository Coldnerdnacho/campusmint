"""
Treasury service - manages club fund allocations and releases
"""

import logging
from datetime import datetime
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional

from app.config import settings
from app.models.database import TreasuryAllocation, TransactionLog
from app.services.algo_client import AlgorandClient

logger = logging.getLogger(__name__)


class TreasuryService:
    """Treasury fund management"""
    
    def __init__(self, algo_client: AlgorandClient, db: Session):
        self.algo_client = algo_client
        self.db = db
    
    def allocate_funds(
        self,
        club_id: str,
        amount: float,
        purpose: str,
        txid: str
    ) -> Dict[str, Any]:
        """
        Create fund allocation request
        
        Args:
            club_id: Club identifier
            amount: Amount in CINR
            purpose: Purpose of allocation
            txid: Transaction ID
        
        Returns:
            Allocation result
        """
        try:
            # Create allocation record
            allocation = TreasuryAllocation(
                club_id=club_id,
                amount=amount,
                purpose=purpose,
                txn_id=txid
            )
            
            self.db.add(allocation)
            
            # Log transaction
            log = TransactionLog(
                txn_id=txid,
                type="allocation",
                address=club_id,
                amount=amount,
                status="pending",
                note=f"Allocation for {purpose}"
            )
            
            self.db.add(log)
            self.db.commit()
            
            logger.info(f"✅ Allocation created for {club_id}: {amount} CINR")
            
            return {
                "success": True,
                "allocation_id": allocation.id,
                "club_id": club_id,
                "amount": amount,
                "status": "pending_approval",
                "created_at": allocation.created_at.isoformat()
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Allocation creation failed: {e}")
            return {"success": False, "error": str(e)}
    
    def approve_allocation(
        self,
        allocation_id: int,
        approved_by: str,
        by_admin: bool = False
    ) -> Dict[str, Any]:
        """
        Approve fund allocation
        
        Args:
            allocation_id: Allocation ID
            approved_by: Approver address
            by_admin: True if admin approval
        
        Returns:
            Approval result
        """
        try:
            allocation = self.db.query(TreasuryAllocation).filter(
                TreasuryAllocation.id == allocation_id
            ).first()
            
            if not allocation:
                return {"success": False, "error": "Allocation not found"}
            
            if by_admin:
                allocation.admin_approval = True
            else:
                allocation.club_lead_approval = True
            
            # Check if fully approved
            if allocation.admin_approval and allocation.club_lead_approval:
                allocation.status = "approved"
                allocation.approved_by = approved_by
            
            allocation.updated_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"✅ Allocation {allocation_id} approved by {approved_by}")
            
            return {
                "success": True,
                "allocation_id": allocation_id,
                "status": allocation.status,
                "approvals": {
                    "admin": allocation.admin_approval,
                    "club_lead": allocation.club_lead_approval
                }
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Approval failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def release_funds(
        self,
        allocation_id: int,
        txid: str
    ) -> Dict[str, Any]:
        """
        Release funds for approved allocation
        
        Args:
            allocation_id: Allocation ID
            txid: Release transaction ID
        
        Returns:
            Release result
        """
        try:
            allocation = self.db.query(TreasuryAllocation).filter(
                TreasuryAllocation.id == allocation_id
            ).first()
            
            if not allocation:
                return {"success": False, "error": "Allocation not found"}
            
            if allocation.status != "approved":
                return {
                    "success": False,
                    "error": f"Cannot release: status is {allocation.status}"
                }
            
            # Mark as released
            allocation.status = "released"
            allocation.txn_id = txid
            allocation.released_at = datetime.utcnow()
            
            # Update transaction log
            log = self.db.query(TransactionLog).filter(
                TransactionLog.txn_id == txid
            ).first()
            
            if log:
                log.status = "confirmed"
                log.confirmed_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"✅ Funds released for allocation {allocation_id}")
            
            return {
                "success": True,
                "allocation_id": allocation_id,
                "club_id": allocation.club_id,
                "amount": allocation.amount,
                "status": "released",
                "released_at": allocation.released_at.isoformat(),
                "txid": txid
            }
        
        except Exception as e:
            self.db.rollback()
            logger.error(f"❌ Fund release failed: {e}")
            return {"success": False, "error": str(e)}
    
    def get_treasury_status(self) -> Dict[str, Any]:
        """Get overall treasury status"""
        try:
            allocations = self.db.query(TreasuryAllocation).all()
            
            total_funds = sum(a.amount for a in allocations)
            available = sum(
                a.amount for a in allocations
                if a.status not in ["released", "approved"]
            )
            allocated = sum(
                a.amount for a in allocations
                if a.status in ["approved", "released"]
            )
            pending = sum(
                a.amount for a in allocations
                if a.status == "pending_approval"
            )
            
            clubs = list(set(a.club_id for a in allocations))
            
            return {
                "total_funds": total_funds,
                "available": available,
                "allocated": allocated,
                "pending_approval": pending,
                "clubs_count": len(clubs),
                "allocations_count": len(allocations)
            }
        
        except Exception as e:
            logger.error(f"❌ Failed to get treasury status: {e}")
            return {
                "error": str(e)
            }
    
    def get_club_allocations(self, club_id: str) -> list:
        """Get allocations for a specific club"""
        try:
            allocations = self.db.query(TreasuryAllocation).filter(
                TreasuryAllocation.club_id == club_id
            ).order_by(
                TreasuryAllocation.created_at.desc()
            ).all()
            
            return [
                {
                    "id": a.id,
                    "amount": a.amount,
                    "purpose": a.purpose,
                    "status": a.status,
                    "created_at": a.created_at.isoformat(),
                    "released_at": a.released_at.isoformat() if a.released_at else None
                }
                for a in allocations
            ]
        
        except Exception as e:
            logger.error(f"❌ Failed to get club allocations: {e}")
            return []

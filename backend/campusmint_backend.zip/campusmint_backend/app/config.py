"""
Configuration management using Pydantic Settings
"""

from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # Algorand
    algod_address: str = "https://testnet-api.algonode.cloud"
    indexer_address: str = "https://testnet-idx.algonode.cloud"
    algod_token: str = ""
    
    # Assets
    cinr_asset_id: int = 755378709
    cinr_decimals: int = 2
    
    # Smart Contracts
    vault_app_id: int = 755379222
    event_app_id: int = 0
    treasury_app_id: int = 0
    nft_ticket_app_id: int = 0
    
    # Admin
    admin_address: str = ""
    admin_mnemonic: str = ""
    
    # Database
    database_url: str = "sqlite:///./campusmint.db"
    
    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    debug: bool = True
    
    # Security
    secret_key: str = "your-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
